﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.Services.Common
{
    public struct MenuOption
    {
        public const double cola = 1.00;
        public const double chips = 0.50;
        public const double candy = 0.65;
    }
}
