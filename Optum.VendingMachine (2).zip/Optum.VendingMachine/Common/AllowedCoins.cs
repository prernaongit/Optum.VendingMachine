﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.Services.Common
{
    public struct AllowedCoins
    {
        public const double NICKLES = 0.05;
        public const double DIMES = 0.1;
        public const double QUARTERS = 0.25;

    }
  
}
