﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Optum.Services.VendingMachine.VendingMachine.Tests
{
    [TestClass]
    public class VendingMachine 
    {
        public void Initialize()
        {

            //initialize variable
        }

        [TestMethod]
        public void Test_CalcualteCurrentAmmount()
        {
            Initialize();

        }

        [TestMethod]
        public void Test_CalcualteCurrentAmmount_WithException()
        {

        }


    }
}
